# AWCREC
Amazon Credentials Checker
> Fiture
+ Auto convert to SMTP
+ Auto create login profile
+ Tell me what features you want to added on this tools :D

Actually i love ur money : 3Jmj6vr8ZKChmV9vGx5zg3insNWkcNsw7E - do u understand boy ? XD
